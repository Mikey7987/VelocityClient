package dev.velocity.mixin;

import dev.velocity.VelocityClient;
import dev.velocity.VelocityConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Shadow @Final private MinecraftClient client;

    /**
     * Stretched resolution: build the projection as if the window had the target
     * aspect (16:9) while still filling the real, wider screen. The picture is
     * horizontally stretched on the phone; squashing the video to 16:9 in an
     * editor restores the exact PC field of view with nothing cropped.
     */
    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true)
    private void velocity$stretch(double fov, CallbackInfoReturnable<Matrix4f> cir) {
        VelocityConfig cfg = VelocityConfig.get();
        if (!cfg.stretchEnabled) return;
        Window w = client.getWindow();
        if (w.getFramebufferHeight() == 0) return;
        float screenAspect = (float) w.getFramebufferWidth() / (float) w.getFramebufferHeight();
        float target = (float) cfg.stretchTargetAspect;
        Matrix4f m = cir.getReturnValue();
        m.m00(m.m00() * screenAspect / target);
        cir.setReturnValue(m);
    }

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void velocity$zoom(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Double> cir) {
        double z = VelocityClient.zoomCurrent;
        if (z < 0.999) cir.setReturnValue(cir.getReturnValue() * z);
    }

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void velocity$noHurtCam(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (VelocityConfig.get().noHurtCam) ci.cancel();
    }
}
