package dev.velocity.mixin;

import dev.velocity.VelocityConfig;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    /** Skip rendering non-player entities beyond a configurable distance. */
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <E extends Entity> void velocity$cull(E entity, Frustum frustum, double x, double y, double z,
                                                  CallbackInfoReturnable<Boolean> cir) {
        VelocityConfig cfg = VelocityConfig.get();
        if (!cfg.entityCulling || entity instanceof PlayerEntity) return;
        double max = cfg.entityCullDistance;
        if (entity.squaredDistanceTo(x, y, z) > max * max) {
            cir.setReturnValue(false);
        }
    }
}
