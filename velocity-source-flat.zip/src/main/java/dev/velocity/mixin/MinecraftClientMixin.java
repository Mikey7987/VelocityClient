package dev.velocity.mixin;

import dev.velocity.VelocityConfig;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Shadow public abstract boolean isWindowFocused();

    /** Drop to a tiny frame rate while the window is in the background. */
    @Inject(method = "getFramerateLimit", at = @At("RETURN"), cancellable = true)
    private void velocity$unfocused(CallbackInfoReturnable<Integer> cir) {
        VelocityConfig cfg = VelocityConfig.get();
        if (cfg.unfocusedFpsCap && !isWindowFocused()) {
            cir.setReturnValue(Math.min(cir.getReturnValue(), cfg.unfocusedFps));
        }
    }
}
