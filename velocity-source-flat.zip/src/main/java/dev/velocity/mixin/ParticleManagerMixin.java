package dev.velocity.mixin;

import dev.velocity.VelocityClient;
import dev.velocity.VelocityConfig;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin {
    /** Per-tick particle budget so explosions/farms can't tank the frame rate. */
    @Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
    private void velocity$limit(Particle particle, CallbackInfo ci) {
        VelocityConfig cfg = VelocityConfig.get();
        if (!cfg.particleLimit) return;
        if (++VelocityClient.particlesThisTick > cfg.maxParticlesPerTick) ci.cancel();
    }
}
