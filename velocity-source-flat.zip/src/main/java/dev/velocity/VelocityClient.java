package dev.velocity;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import dev.velocity.mixin.SimpleOptionAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class VelocityClient implements ClientModInitializer {
    public static volatile int particlesThisTick = 0;
    public static volatile double zoomCurrent = 1.0;

    private static final String CATEGORY = "category.velocity";
    private static KeyBinding zoomKey, stretchKey, fullbrightKey;
    private static double savedGamma = 1.0;
    private static boolean fullbrightApplied = false;

    @Override
    public void onInitializeClient() {
        VelocityConfig.load();

        zoomKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.velocity.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));
        stretchKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.velocity.stretch", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, CATEGORY));
        fullbrightKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key.velocity.fullbright", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, CATEGORY));

        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudRenderCallback.EVENT.register(this::renderHud);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> registerCommands(dispatcher));
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> {
            restoreGamma(c);
            VelocityConfig.save();
        });
    }

    // ------------------------------------------------------------------ tick

    private void tick(MinecraftClient client) {
        VelocityConfig cfg = VelocityConfig.get();
        particlesThisTick = 0;

        while (stretchKey.wasPressed()) {
            cfg.stretchEnabled = !cfg.stretchEnabled;
            msg(client, "Stretched resolution " + (cfg.stretchEnabled ? "ON (" + ratioText(cfg) + ")" : "OFF"));
            VelocityConfig.save();
        }
        while (fullbrightKey.wasPressed()) {
            cfg.fullbright = !cfg.fullbright;
            msg(client, "Fullbright " + (cfg.fullbright ? "ON" : "OFF"));
            VelocityConfig.save();
        }

        // Smooth zoom
        double target = zoomKey.isPressed() ? cfg.zoomFactor : 1.0;
        zoomCurrent += (target - zoomCurrent) * 0.35;
        if (Math.abs(zoomCurrent - target) < 0.002) zoomCurrent = target;

        applyFullbright(client, cfg);

        // Auto sprint
        if (cfg.autoSprint && client.player != null) {
            var p = client.player;
            if (client.options.forwardKey.isPressed() && !p.isSneaking() && !p.horizontalCollision
                    && p.getHungerManager().getFoodLevel() > 6) {
                p.setSprinting(true);
            }
        }
    }

    private static void applyFullbright(MinecraftClient client, VelocityConfig cfg) {
        if (client.options == null) return;
        var opt = client.options.getGamma();
        if (cfg.fullbright) {
            if (!fullbrightApplied) {
                if (opt.getValue() <= 1.0) savedGamma = opt.getValue();
                fullbrightApplied = true;
            }
            ((SimpleOptionAccessor<Double>) (Object) opt).velocity$setValueUnchecked(16.0);
        } else if (fullbrightApplied) {
            restoreGamma(client);
        }
    }

    private static void restoreGamma(MinecraftClient client) {
        if (!fullbrightApplied || client.options == null) return;
        ((SimpleOptionAccessor<Double>) (Object) client.options.getGamma()).velocity$setValueUnchecked(savedGamma);
        fullbrightApplied = false;
    }

    // ------------------------------------------------------------------- HUD

    private void renderHud(net.minecraft.client.gui.DrawContext ctx, net.minecraft.client.render.RenderTickCounter tick) {
        VelocityConfig cfg = VelocityConfig.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!cfg.hud || mc.options.hudHidden || mc.player == null) return;
        if (mc.getDebugHud().shouldShowDebugHud()) return;

        var tr = mc.textRenderer;
        int y = 4;
        ctx.drawTextWithShadow(tr, "FPS: " + mc.getCurrentFps(), 4, y, 0xFFFFFF);
        y += 10;
        ctx.drawTextWithShadow(tr, String.format("XYZ: %d %d %d",
                mc.player.getBlockX(), mc.player.getBlockY(), mc.player.getBlockZ()), 4, y, 0xAAAAAA);
        if (cfg.stretchEnabled) {
            y += 10;
            ctx.drawTextWithShadow(tr, "Stretch " + ratioText(cfg), 4, y, 0x55FFFF);
        }
    }

    // -------------------------------------------------------------- commands

    private void registerCommands(com.mojang.brigadier.CommandDispatcher<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> d) {
        var root = ClientCommandManager.literal("velocity");

        root.then(ClientCommandManager.literal("stretch")
                .executes(c -> {
                    var cfg = VelocityConfig.get();
                    cfg.stretchEnabled = !cfg.stretchEnabled;
                    VelocityConfig.save();
                    c.getSource().sendFeedback(Text.literal("Stretch " + (cfg.stretchEnabled ? "ON " + ratioText(cfg) : "OFF")));
                    return 1;
                })
                .then(ClientCommandManager.literal("on").executes(c -> setStretch(c.getSource(), true)))
                .then(ClientCommandManager.literal("off").executes(c -> setStretch(c.getSource(), false)))
                .then(ClientCommandManager.literal("ratio")
                        .then(ClientCommandManager.argument("w", DoubleArgumentType.doubleArg(1, 100))
                                .then(ClientCommandManager.argument("h", DoubleArgumentType.doubleArg(1, 100))
                                        .executes(c -> {
                                            var cfg = VelocityConfig.get();
                                            cfg.stretchTargetAspect = DoubleArgumentType.getDouble(c, "w") / DoubleArgumentType.getDouble(c, "h");
                                            cfg.stretchEnabled = true;
                                            VelocityConfig.save();
                                            c.getSource().sendFeedback(Text.literal("Stretch target set to " + ratioText(cfg)));
                                            return 1;
                                        })))));

        root.then(ClientCommandManager.literal("fullbright").executes(c -> {
            var cfg = VelocityConfig.get();
            cfg.fullbright = !cfg.fullbright;
            VelocityConfig.save();
            c.getSource().sendFeedback(Text.literal("Fullbright " + (cfg.fullbright ? "ON" : "OFF")));
            return 1;
        }));

        root.then(ClientCommandManager.literal("sprint").executes(c -> {
            var cfg = VelocityConfig.get();
            cfg.autoSprint = !cfg.autoSprint;
            VelocityConfig.save();
            c.getSource().sendFeedback(Text.literal("Auto sprint " + (cfg.autoSprint ? "ON" : "OFF")));
            return 1;
        }));

        root.then(ClientCommandManager.literal("hud").executes(c -> {
            var cfg = VelocityConfig.get();
            cfg.hud = !cfg.hud;
            VelocityConfig.save();
            c.getSource().sendFeedback(Text.literal("HUD " + (cfg.hud ? "ON" : "OFF")));
            return 1;
        }));

        root.then(ClientCommandManager.literal("cull")
                .then(ClientCommandManager.argument("blocks", IntegerArgumentType.integer(8, 256))
                        .executes(c -> {
                            var cfg = VelocityConfig.get();
                            cfg.entityCullDistance = IntegerArgumentType.getInteger(c, "blocks");
                            cfg.entityCulling = true;
                            VelocityConfig.save();
                            c.getSource().sendFeedback(Text.literal("Entity cull distance: " + cfg.entityCullDistance + " blocks"));
                            return 1;
                        })));

        root.then(ClientCommandManager.literal("preset")
                .then(ClientCommandManager.literal("potato").executes(c -> {
                    applyPotatoPreset(MinecraftClient.getInstance());
                    c.getSource().sendFeedback(Text.literal("Applied low-end video settings."));
                    return 1;
                })));

        d.register(root);
    }

    private static int setStretch(net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource src, boolean on) {
        var cfg = VelocityConfig.get();
        cfg.stretchEnabled = on;
        VelocityConfig.save();
        src.sendFeedback(Text.literal("Stretch " + (on ? "ON " + ratioText(cfg) : "OFF")));
        return 1;
    }

    /** Low-end preset: every vanilla video option that costs frames, turned down. */
    private static void applyPotatoPreset(MinecraftClient mc) {
        GameOptions o = mc.options;
        o.getViewDistance().setValue(8);
        o.getSimulationDistance().setValue(6);
        o.getGraphicsMode().setValue(GraphicsMode.FAST);
        o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getEntityShadows().setValue(false);
        o.getBiomeBlendRadius().setValue(0);
        o.getMipmapLevels().setValue(0);
        o.getEntityDistanceScaling().setValue(0.5);
        o.getEnableVsync().setValue(false);
        o.write();
    }

    // --------------------------------------------------------------- helpers

    private static String ratioText(VelocityConfig cfg) {
        double a = cfg.stretchTargetAspect;
        if (Math.abs(a - 16.0 / 9.0) < 0.001) return "16:9";
        if (Math.abs(a - 4.0 / 3.0) < 0.001) return "4:3";
        return String.format("%.3f:1", a);
    }

    private static void msg(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("[Velocity] " + s), true);
    }
}
