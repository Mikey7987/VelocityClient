package dev.velocity;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class VelocityConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("velocity.json");
    private static VelocityConfig instance = new VelocityConfig();

    // --- Stretched resolution (for video) ---
    public boolean stretchEnabled = false;
    public double stretchTargetAspect = 16.0 / 9.0;

    // --- Performance ---
    public boolean entityCulling = true;
    public int entityCullDistance = 48;
    public boolean particleLimit = true;
    public int maxParticlesPerTick = 40;
    public boolean unfocusedFpsCap = true;
    public int unfocusedFps = 10;

    // --- QoL ---
    public boolean noHurtCam = true;
    public boolean autoSprint = false;
    public boolean fullbright = false;
    public boolean hud = true;
    public double zoomFactor = 0.25;

    public static VelocityConfig get() {
        return instance;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                VelocityConfig loaded = GSON.fromJson(Files.readString(FILE), VelocityConfig.class);
                if (loaded != null) instance = loaded;
            }
        } catch (Exception e) {
            System.err.println("[Velocity] Could not read config, using defaults: " + e);
        }
        save();
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(instance));
        } catch (IOException e) {
            System.err.println("[Velocity] Could not save config: " + e);
        }
    }
}
