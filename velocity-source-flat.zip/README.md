# Velocity Client (Fabric 1.21.1)

Client-side only. Needs Fabric Loader 0.16+, Fabric API, Java 21.

## Build
    gradle build        # or ./gradlew build if you add the wrapper
Jar ends up in `build/libs/velocity-client-1.0.0.jar` (not the `-sources` one).

## Stretched resolution (for video)
1. `/velocity stretch on` (or press J). Default target is 16:9.
2. Record as normal. The world fills your phone screen, horizontally stretched.
3. In your editor, set the project to 16:9 (1920x1080) and scale the clip to fill
   the frame WITHOUT keeping aspect ratio (squash, don't crop).
   Or with ffmpeg:
       ffmpeg -i in.mp4 -vf "scale=1920:1080,setsar=1" -c:a copy out.mp4
Other ratio: `/velocity stretch ratio 21 9`.
Note: HUD/hotbar/chat are not pre-compensated, so they look squashed in the final
video. Hide the HUD (F1) for clean footage.

## Commands
/velocity stretch [on|off|ratio <w> <h>], fullbright, sprint, hud, cull <blocks>, preset potato

## Keys
C zoom (hold), J stretch, K fullbright (rebind in Controls)

## Config
config/velocity.json
